package poly.com.servlet;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String remember = request.getParameter("remember"); // checkbox

        if (username == null) username = "";
        if (password == null) password = "";

        if (!username.equals("abc")) {
            request.setAttribute("message", "Username invalid!");
        } else if (!password.equals("123")) {
            request.setAttribute("message", "Password invalid!");
        } else {
            request.setAttribute("message", "Login Success!");
        }

        // Xử lý cookie dựa trên checkbox
        if ("on".equals(remember)) {
            // Tick → lưu cookie 24h
            poly.com.utils.Cookies.add("username", username, 24, response);
            poly.com.utils.Cookies.add("password", password, 24, response);
        } else {
            // Không tick → xóa cookie nếu tồn tại
            poly.com.utils.Cookies.add("username", "", 0, response);
            poly.com.utils.Cookies.add("password", "", 0, response);
        }

        request.setAttribute("username", username);
        request.setAttribute("password", password);

        request.getRequestDispatcher("/views/login.jsp").forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = poly.com.utils.Cookies.get("username", request);
        String password = poly.com.utils.Cookies.get("password", request);
        boolean cookieExists = !username.isEmpty();

        request.setAttribute("username", username);
        request.setAttribute("password", password);
        request.setAttribute("cookieExists", cookieExists);

        request.getRequestDispatcher("/views/login.jsp").forward(request, response);
    }

}
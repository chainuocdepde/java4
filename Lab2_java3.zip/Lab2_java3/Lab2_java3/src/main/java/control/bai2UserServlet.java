package control;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse; 

@WebServlet("/bai2UserServlet")
public class bai2UserServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
        // TODO Auto-generated method stub
        
       
        req.setAttribute("message", "webcome to fpt poly");
        
     
        Map<String, Object> map = new HashMap<>(); 
        map.put("fullname", "Trương Công Gia Bảo");
        map.put("gender", "male");
        map.put("country", "viet nam");
        
      
        req.setAttribute("user", map);
        
       
        req.getRequestDispatcher("page.jsp").forward(req, resp);
    }
}

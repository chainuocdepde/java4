package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.DepartmentInterfaceDAO;
import poly.com.model.Departments;

import java.io.IOException;
import java.util.List;

@WebServlet("/departments4/list")
public class DepartmentListController extends HttpServlet {

    private DepartmentInterfaceDAO dao = new DepartmentInterfaceDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // Lấy dữ liệu từ DB
        List<Departments> list = dao.selectAll();

        // Gửi qua JSP
        req.setAttribute("departments", list);

        // Chuyển sang trang list4.jsp
        req.getRequestDispatcher("/departments4/list4.jsp").forward(req, resp);
    }
}

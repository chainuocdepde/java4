package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.DepartmentInterfaceDAO;
import poly.com.dao.EmployeeInterfaceDAO;
import poly.com.model.Departments;
import poly.com.model.Employees;

import java.io.IOException;
import java.util.List;

@WebServlet("/departments4/details")
public class DepartmentDetailsController extends HttpServlet {

    private EmployeeInterfaceDAO employeeDAO = new EmployeeInterfaceDAO();
    private DepartmentInterfaceDAO departmentDAO = new DepartmentInterfaceDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String id = req.getParameter("id");

        if (id == null || id.isEmpty()) {
            res.sendRedirect(req.getContextPath() + "/departments4");
            return;
        }

        Departments department = departmentDAO.selectById(id);
        List<Employees> employeesList = employeeDAO.selectAllWithDepartmentId(id);

        req.setAttribute("department", department);
        req.setAttribute("employeesList", employeesList);

        req.getRequestDispatcher("/departments4/department-details.jsp")
                .forward(req, res);
    }
}

package poly.com.dao;

public class maintest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			DeparmentDao Dedao = new DeparmentDao();
			Dedao.printAllDepartments();
			Dedao.insertDepartment("008", "Phòng ngủ","Phòng chỉ để ngủ");
	}

}
